using System;
using Xunit;

namespace EVErything.Test.Business
{
    public class SimpleTest
    {
        [Fact]
        public void Test1()
        {
            Assert.Equal(2, 2);
        }
    }
}
