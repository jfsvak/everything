﻿namespace EVErything.Web.Controllers
{
    public class HttpActionExecutedContext
    {
    }
}